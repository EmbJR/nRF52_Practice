# nRF Connect SDK Intermediate Course Exercises
This repository is part of the [nRF Connect SDK Intermediate](https://academy.nordicsemi.com/courses/nrf-connect-sdk-intermediate/) course by [Nordic Developer Academy](https://academy.nordicsemi.com).

The nRF Connect SDK Intermediate course is a self-paced, hands-on online course that is aimed at empowering developers to master advanced topics and techniques for developing applications using the nRF Connect SDK. The course is designed to enable developers with some experience in the nRF Connect SDK to take their skills to the next level.

The course covers a wide range of topics, including thread management, data passing, debugging applications, adding support for custom boards, interacting with the SPI, ADC, and PWM peripherals, device driver development, and secure Device Firmware Update (DFU/FOTA) over different transports. The skills and knowledge gained from this course are applicable to any of Nordic Semiconductor’s devices, including the nRF91, nRF70, nRF53, and nRF52 Series.

This repository contains the exercise code base and solutions. Make sure to select the branch that corresponds with the nRF Connect SDK version of your choosing:
<ul>
    <li><code>main</code>: For nRF Connect SDK version v3.2.0 </li> 
</ul>

The course supports the following hardware:
 - [nRF54LM20 DK](https://www.nordicsemi.com/Products/Development-hardware/nRF54LM20-DK) - On nRF Connect SDK v3.1.1 and above
 - [nRF54L15 DK](https://www.nordicsemi.com/Products/Development-hardware/nRF54L15-DK) - On nRF Connect SDK v2.8.0 and above.
 - [nRF5340 DK](https://www.nordicsemi.com/Software-and-tools/Development-Kits/nRF5340-DK) 
 - [nRF52840 DK](https://www.nordicsemi.com/Software-and-tools/Development-Kits/nRF52840-DK)
 - [nRF52833 DK](https://www.nordicsemi.com/Software-and-tools/Development-Kits/nRF52833-DK)
 - [nRF52 DK](https://www.nordicsemi.com/Products/Development-hardware/nrf52-dk)
 - [nRF9160 DK](https://www.nordicsemi.com/Products/Development-hardware/nrf9160-dk)
 - [nRF9161 DK](https://www.nordicsemi.com/Products/Development-hardware/nRF9161-DK)
 - [nRF9151 DK](https://www.nordicsemi.com/Products/Development-hardware/nRF9151-DK) - On nRF Connect SDK v2.6.0 and above.
 - [nRF9151 SMA DK](https://www.nordicsemi.com/Products/Development-hardware/nRF9151-SMA-DK)
 - [nRF7002 DK](https://www.nordicsemi.com/Products/Development-hardware/nRF7002-DK)
